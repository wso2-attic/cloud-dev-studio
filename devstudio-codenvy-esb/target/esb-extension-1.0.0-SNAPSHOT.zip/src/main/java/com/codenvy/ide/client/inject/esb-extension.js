
function foo(){
alert("foooo");
}
